// src/create-request-handler.ts
function createRPCRequestHandler(handler) {
  return handler;
}
// src/rpc.ts
var MAX_ID = 10000000000;
var DEFAULT_MAX_REQUEST_TIME = 1000;
function missingTransportMethodError(methods, action) {
  const methodsString = methods.map((method) => `"${method}"`).join(", ");
  return new Error(`This RPC instance cannot ${action} because the transport did not provide one or more of these methods: ${methodsString}`);
}
function _createRPC(options = {}) {
  let debugHooks = {};
  function _setDebugHooks(newDebugHooks) {
    debugHooks = newDebugHooks;
  }
  let transport = {};
  function setTransport(newTransport) {
    if (transport.unregisterHandler)
      transport.unregisterHandler();
    transport = newTransport;
    transport.registerHandler?.(handler);
  }
  let requestHandler = undefined;
  function setRequestHandler(handler) {
    if (typeof handler === "function") {
      requestHandler = handler;
      return;
    }
    requestHandler = (method, params) => {
      const handlerFn = handler[method];
      if (handlerFn)
        return handlerFn(params);
      const fallbackHandler = handler._;
      if (!fallbackHandler)
        throw new Error(`The requested method has no handler: ${method}`);
      return fallbackHandler(method, params);
    };
  }
  const { maxRequestTime = DEFAULT_MAX_REQUEST_TIME } = options;
  if (options.transport)
    setTransport(options.transport);
  if (options.requestHandler)
    setRequestHandler(options.requestHandler);
  if (options._debugHooks)
    _setDebugHooks(options._debugHooks);
  let lastRequestId = 0;
  function getRequestId() {
    if (lastRequestId <= MAX_ID)
      return ++lastRequestId;
    return lastRequestId = 0;
  }
  const requestListeners = new Map;
  const requestTimeouts = new Map;
  function requestFn(method, ...args) {
    const params = args[0];
    return new Promise((resolve, reject) => {
      if (!transport.send)
        throw missingTransportMethodError(["send"], "make requests");
      const requestId = getRequestId();
      const request = {
        type: "request",
        id: requestId,
        method,
        params
      };
      requestListeners.set(requestId, { resolve, reject });
      if (maxRequestTime !== Infinity)
        requestTimeouts.set(requestId, setTimeout(() => {
          requestTimeouts.delete(requestId);
          reject(new Error("RPC request timed out."));
        }, maxRequestTime));
      debugHooks.onSend?.(request);
      transport.send(request);
    });
  }
  const request = new Proxy(requestFn, {
    get: (target, prop, receiver) => {
      if (prop in target)
        return Reflect.get(target, prop, receiver);
      return (params) => requestFn(prop, params);
    }
  });
  const requestProxy = request;
  function sendFn(message, ...args) {
    const payload = args[0];
    if (!transport.send)
      throw missingTransportMethodError(["send"], "send messages");
    const rpcMessage = {
      type: "message",
      id: message,
      payload
    };
    debugHooks.onSend?.(rpcMessage);
    transport.send(rpcMessage);
  }
  const send = new Proxy(sendFn, {
    get: (target, prop, receiver) => {
      if (prop in target)
        return Reflect.get(target, prop, receiver);
      return (payload) => sendFn(prop, payload);
    }
  });
  const sendProxy = send;
  const messageListeners = new Map;
  const wildcardMessageListeners = new Set;
  function addMessageListener(message, listener) {
    if (!transport.registerHandler)
      throw missingTransportMethodError(["registerHandler"], "register message listeners");
    if (message === "*") {
      wildcardMessageListeners.add(listener);
      return;
    }
    if (!messageListeners.has(message))
      messageListeners.set(message, new Set);
    messageListeners.get(message)?.add(listener);
  }
  function removeMessageListener(message, listener) {
    if (message === "*") {
      wildcardMessageListeners.delete(listener);
      return;
    }
    messageListeners.get(message)?.delete(listener);
    if (messageListeners.get(message)?.size === 0)
      messageListeners.delete(message);
  }
  async function handler(message) {
    debugHooks.onReceive?.(message);
    if (!("type" in message))
      throw new Error("Message does not contain a type.");
    if (message.type === "request") {
      if (!transport.send || !requestHandler)
        throw missingTransportMethodError(["send", "requestHandler"], "handle requests");
      const { id, method, params } = message;
      let response;
      try {
        response = {
          type: "response",
          id,
          success: true,
          payload: await requestHandler(method, params)
        };
      } catch (error) {
        if (!(error instanceof Error))
          throw error;
        response = {
          type: "response",
          id,
          success: false,
          error: error.message
        };
      }
      debugHooks.onSend?.(response);
      transport.send(response);
      return;
    }
    if (message.type === "response") {
      const timeout = requestTimeouts.get(message.id);
      if (timeout != null)
        clearTimeout(timeout);
      const { resolve, reject } = requestListeners.get(message.id) ?? {};
      if (!message.success)
        reject?.(new Error(message.error));
      else
        resolve?.(message.payload);
      return;
    }
    if (message.type === "message") {
      for (const listener of wildcardMessageListeners)
        listener(message.id, message.payload);
      const listeners = messageListeners.get(message.id);
      if (!listeners)
        return;
      for (const listener of listeners)
        listener(message.payload);
      return;
    }
    throw new Error(`Unexpected RPC message type: ${message.type}`);
  }
  const proxy = { send: sendProxy, request: requestProxy };
  return {
    setTransport,
    setRequestHandler,
    request,
    requestProxy,
    send,
    sendProxy,
    addMessageListener,
    removeMessageListener,
    proxy,
    _setDebugHooks
  };
}

// src/create-rpc.ts
function createRPC(options) {
  return _createRPC(options);
}
// src/transport-utils.ts
var transportIdKey = "[transport-id]";
function rpcTransportMessageOut(data, options) {
  const { transportId } = options;
  if (transportId != null)
    return { [transportIdKey]: transportId, data };
  return data;
}
function rpcTransportMessageIn(message, options) {
  const { transportId, filter } = options;
  const filterResult = filter?.();
  if (transportId != null && filterResult != null)
    throw new Error("Cannot use both `transportId` and `filter` at the same time");
  let data = message;
  if (transportId) {
    if (message[transportIdKey] !== transportId)
      return [true];
    data = message.data;
  }
  if (filterResult === false)
    return [true];
  return [false, data];
}
// src/transports/message-port.ts
function createTransportFromMessagePort(port, options = {}) {
  const { transportId, filter, remotePort } = options;
  const local = port;
  const remote = remotePort ?? port;
  let transportHandler;
  return {
    send(data) {
      remote.postMessage(rpcTransportMessageOut(data, { transportId }));
    },
    registerHandler(handler) {
      transportHandler = (event) => {
        const message = event.data;
        const [ignore, data] = rpcTransportMessageIn(message, {
          transportId,
          filter: () => filter?.(event)
        });
        if (ignore)
          return;
        handler(data);
      };
      local.addEventListener("message", transportHandler);
    },
    unregisterHandler() {
      if (transportHandler)
        local.removeEventListener("message", transportHandler);
    }
  };
}
// src/transports/iframe.ts
var IFRAME_MSG_KEY = "[iframe-transport]";
var IFRAME_READY_MSG = "[iframe-transport-ready]";
async function waitForLoad(element) {
  const readyState = element.contentDocument?.readyState;
  const location = element.contentWindow?.location.href;
  return location !== "about:blank" && readyState === "complete" ? Promise.resolve() : new Promise((resolve) => element.addEventListener("load", resolve));
}
async function portReadyPromise(port) {
  return new Promise((resolve) => {
    port.addEventListener("message", function ready(event) {
      if (event.data === IFRAME_READY_MSG) {
        port.removeEventListener("message", ready);
        resolve();
      }
    });
  });
}
async function createIframeTransport(iframe, options = {}) {
  const channel = new MessageChannel;
  const { port1, port2 } = channel;
  port1.start();
  const transport = createTransportFromMessagePort(port1, options);
  const readyPromise = portReadyPromise(port1);
  await waitForLoad(iframe);
  if (!iframe.contentWindow)
    throw new Error("Unexpected iframe state");
  iframe.contentWindow.postMessage({ [IFRAME_MSG_KEY]: options.transportId ?? "default" }, options.targetOrigin ?? "*", [port2]);
  await readyPromise;
  return transport;
}
async function waitForInit(id) {
  return new Promise((resolve) => {
    window.addEventListener("message", function init(event) {
      const { data, ports } = event;
      if (data[IFRAME_MSG_KEY] === id) {
        const [port] = ports;
        window.removeEventListener("message", init);
        resolve(port);
      }
    });
  });
}
async function createIframeParentTransport(options = {}) {
  const port = await waitForInit(options.transportId ?? "default");
  port.start();
  port.postMessage(IFRAME_READY_MSG);
  return createTransportFromMessagePort(port, options);
}
// demo/iframe.ts
var syncedInputEl = el("synced-input");
var coloredButtonEl = el("colored-button");
var storyButtonEl = el("story-button");
var storyResultEl = el("story-result");
var storyTitleEl = el("story-title");
var storyVillageNameEl = el("story-village-name-input");
var storyAnimalEl = el("story-animal-input");
var storyNameEl = el("story-name-input");
var storyActivityEl = el("story-activity-input");
var storyLandmarkEl = el("story-landmark-input");
var storyObjectEl = el("story-object-input");
var storySuperpowerEl = el("story-superpower-input");
var storyNewTitleEl = el("story-new-title-input");
var colors = ["red", "green", "blue", "purple"];
var requestHandler = createRPCRequestHandler({
  getColor: () => coloredButtonEl.dataset.color
});
async function main() {
  const rpc = createRPC({
    transport: await createIframeParentTransport({
      transportId: "rpc-anywhere-demo"
    }),
    requestHandler,
    _debugHooks: { onSend: _debugOnSend, onReceive: _debugOnReceive }
  });
  const parent = rpc.proxy;
  syncedInputEl.addEventListener("input", () => parent.send.iframeInputUpdated(syncedInputEl.value));
  rpc.addMessageListener("parentInputUpdated", (value) => syncedInputEl.value = value);
  storyButtonEl.addEventListener("click", async () => {
    const { title } = await parent.request.createStory({
      villageName: storyVillageNameEl.value,
      animal: storyAnimalEl.value,
      name: storyNameEl.value,
      activity: storyActivityEl.value,
      landmark: storyLandmarkEl.value,
      object: storyObjectEl.value,
      superpower: storySuperpowerEl.value,
      newTitle: storyNewTitleEl.value
    });
    storyResultEl.style.removeProperty("display");
    storyTitleEl.textContent = title;
  });
}
main();
var colorToClass = {
  red: "bg-red-500",
  green: "bg-green-500",
  blue: "bg-blue-500",
  purple: "bg-purple-500"
};
function updateButtonColor(color) {
  const currentColor = coloredButtonEl.dataset.color;
  const currentClass = colorToClass[currentColor];
  const nextColor = color ?? colors[(colors.indexOf(currentColor) + 1) % colors.length];
  const nextClass = colorToClass[nextColor];
  coloredButtonEl.dataset.color = nextColor;
  coloredButtonEl.classList.remove(currentClass);
  coloredButtonEl.classList.add(nextClass);
}
coloredButtonEl.addEventListener("click", () => updateButtonColor());
function el(id) {
  const element = document.getElementById(id);
  if (!element)
    throw new Error(`Element with id ${id} not found`);
  return element;
}
var iframeLogsEl = window.parent.document.querySelector("#iframe-logs");
function _debugOnSend(packet) {
  console.log("[iframe] sent", packet);
  window.parent._debugAppendMessage("send", iframeLogsEl, packet);
}
function _debugOnReceive(packet) {
  console.log("[iframe] received", packet);
  window.parent._debugAppendMessage("receive", iframeLogsEl, packet);
}
